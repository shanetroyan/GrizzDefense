﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public class Wave
{
    public GameObject orcPrefab;
    public float orcSpawnInterval = 2;
    public int maxOrcs = 20;
    public GameObject goblinPrefab;
    public float goblinSpawnInterval = 2;
    public int maxGoblins = 20;
    public GameObject ogrePrefab;
    public float ogreSpawnInterval = 2;
    public int maxOgres = 20;
    public GameObject worgRiderPrefab;
    public float worgRiderSpawnInterval = 2;
    public int maxWorgRiders = 20;
}

public class SpawnEnemy : MonoBehaviour
{
    public GameObject[] waypoints;

    public Wave[] waves;
    public int timeBetweenWaves = 5;

    private GameManagerBehaviour gameManager;

    private float lastOrcSpawnTime;
    private float lastGoblinSpawnTime;
    private float lastOgreSpawnTime;
    private float lastWorgRiderSpawnTime;
    private int orcsSpawned = 0;
    private int goblinsSpawned = 0;
    private int ogresSpawned = 0;
    private int worgRidersSpawned = 0;

    // Start is called before the first frame update
    void Start()
    {
        lastOrcSpawnTime = Time.time;
        lastGoblinSpawnTime = Time.time;
        lastOgreSpawnTime = Time.time;
        lastWorgRiderSpawnTime = Time.time;
        gameManager =
            GameObject.Find("GameManager").GetComponent<GameManagerBehaviour>();
    }

    // Update is called once per frame
    void Update()
    {
        // 1
        int currentWave = gameManager.Wave;
        if (currentWave < waves.Length)
        {
            // 2
            float orcTimeInterval = Time.time - lastOrcSpawnTime;
            float goblinTimeInterval = Time.time - lastGoblinSpawnTime;
            float ogreTimeInterval = Time.time - lastOgreSpawnTime;
            float worgRiderTimeInterval = Time.time - lastWorgRiderSpawnTime;
            float orcSpawnInterval = waves[currentWave].orcSpawnInterval;
            float goblinSpawnInterval = waves[currentWave].goblinSpawnInterval;
            float ogreSpawnInterval = waves[currentWave].ogreSpawnInterval;
            float worgRiderSpawnInterval = waves[currentWave].worgRiderSpawnInterval;

            if (((orcsSpawned == 0 && orcTimeInterval > timeBetweenWaves) ||
                orcTimeInterval > orcSpawnInterval) &&
                orcsSpawned < waves[currentWave].maxOrcs)
            {
                // 3  
                lastOrcSpawnTime = Time.time;
                GameObject newOrc = (GameObject)
                    Instantiate(waves[currentWave].orcPrefab);
                newOrc.GetComponent<MoveEnemy>().waypoints = waypoints;
                orcsSpawned++;
            }

            if (((goblinsSpawned == 0 && goblinTimeInterval > timeBetweenWaves) ||
                 goblinTimeInterval > goblinSpawnInterval) &&
                goblinsSpawned < waves[currentWave].maxGoblins)
            {
                // 3  
                lastGoblinSpawnTime = Time.time;
                GameObject newGoblin = (GameObject)
                    Instantiate(waves[currentWave].goblinPrefab);
                newGoblin.GetComponent<MoveEnemy>().waypoints = waypoints;
                goblinsSpawned++;
            }

            if (((ogresSpawned == 0 && ogreTimeInterval > timeBetweenWaves) ||
                ogreTimeInterval > ogreSpawnInterval) &&
                ogresSpawned < waves[currentWave].maxOgres)
            {
                // 3  
                lastOgreSpawnTime = Time.time;
                GameObject newOgre = (GameObject)
                    Instantiate(waves[currentWave].ogrePrefab);
                newOgre.GetComponent<MoveEnemy>().waypoints = waypoints;
                ogresSpawned++;
            }

            if (((worgRidersSpawned == 0 && worgRiderTimeInterval > timeBetweenWaves) ||
                 worgRiderTimeInterval > worgRiderSpawnInterval) &&
                worgRidersSpawned < waves[currentWave].maxWorgRiders)
            {
                // 3  
                lastWorgRiderSpawnTime = Time.time;
                GameObject newWorgRider = (GameObject)
                    Instantiate(waves[currentWave].worgRiderPrefab);
                newWorgRider.GetComponent<MoveEnemy>().waypoints = waypoints;
                worgRidersSpawned++;
            }

            // 4 
            if (orcsSpawned == waves[currentWave].maxOrcs &&
                goblinsSpawned == waves[currentWave].maxGoblins &&
                ogresSpawned == waves[currentWave].maxOgres &&
                worgRidersSpawned == waves[currentWave].maxWorgRiders &&
                GameObject.FindGameObjectWithTag("Enemy") == null)
            {
                gameManager.Wave++;
                gameManager.Gold = Mathf.RoundToInt(gameManager.Gold * 1.1f);
                gameManager.Points = Mathf.RoundToInt(gameManager.Points * 1.1f);
                orcsSpawned = 0;
                goblinsSpawned = 0;
                ogresSpawned = 0;
                worgRidersSpawned = 0;
                lastOrcSpawnTime = Time.time;
                lastGoblinSpawnTime = Time.time;
                lastOgreSpawnTime = Time.time;
                lastWorgRiderSpawnTime = Time.time;
            }
            // 5 
        }
        else
        {
            gameManager.gameOver = true;
            GameObject gameOverText = GameObject.FindGameObjectWithTag("GameWon");
            gameOverText.GetComponent<Animator>().SetBool("gameOver", true);
        }
    }
}
