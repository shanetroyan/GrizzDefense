﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuControllerOrig : MonoBehaviour
{
    // Start is called before the first frame update

    public string MainMenuScene;
    public GameObject PauseScreen;
    public bool isPaused;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
       
        
        
        
        
        
        
        
        
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPaused)
            {
                isPaused = false;
                PauseScreen.SetActive(false);
                Time.timeScale = 1f;
            }
            else
            {
                isPaused = true;
                PauseScreen.SetActive(true);
                Time.timeScale = 0.0001f;
            }

        }
    }
    public void resumeGame()
    {
        isPaused = false;
        PauseScreen.SetActive(false);
        Time.timeScale = 1f;
    }

    public void ReturntoMainMenu()
    {
        SceneManager.LoadScene(MainMenuScene);
    }

}
