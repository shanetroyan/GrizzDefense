﻿using System;
using Unity;
using UnityEngine;
public class QuitGame: MonoBehaviour
{
	public void exitGame()
	{
        Debug.Log("Game has exited successfully");
        Application.Quit();
	}
}
