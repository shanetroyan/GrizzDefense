﻿
using UnityEngine;
using System.Collections;


public class PauseMenu : MonoBehaviour
    {

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Application.LoadLevel("PauseMenu");
            }
        }
    }



