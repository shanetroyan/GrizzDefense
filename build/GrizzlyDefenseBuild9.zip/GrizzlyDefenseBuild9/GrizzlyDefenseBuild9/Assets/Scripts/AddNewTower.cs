﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AddNewTower : MonoBehaviour
{
    public GameObject ArrowTowerPrefab;
    private GameObject ArrowTower;
    public GameObject CannonTowerPrefab;
    private GameObject CannonTower;
    public GameObject MageTowerPrefab;
    private GameObject MageTower;
    private GameManagerBehaviour gameManager;



    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManagerBehaviour>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private bool CanPlaceTower(char x)
    {
        if (x == 'a')
        {
            int cost = ArrowTowerPrefab.GetComponent<TowerData>().levels[0].cost;
            return ArrowTower == null && gameManager.Gold >= cost;
        }
        else if (x == 'c')
        {
            int cost = CannonTowerPrefab.GetComponent<TowerData>().levels[0].cost;
            return CannonTower == null && gameManager.Gold >= cost;
        }
        else if (x == 'm')
        {
            int cost = MageTowerPrefab.GetComponent<TowerData>().levels[0].cost;
            return MageTower == null && gameManager.Gold >= cost;
        }
        return false;
    }

    private bool CanUpgradeTower(char x)
    {
        if (x == 'a')
        {
            if (ArrowTower != null)
            {
                TowerData towerData = ArrowTower.GetComponent<TowerData>();
                TowerLevel nextLevel = towerData.GetNextLevel();
                if (nextLevel != null)
                {
                    return gameManager.Gold >= nextLevel.cost;
                }
            }
        }
        else if (x == 'c')
        {
            if (CannonTower != null)
            {
                TowerData towerData = CannonTower.GetComponent<TowerData>();
                TowerLevel nextLevel = towerData.GetNextLevel();
                if (nextLevel != null)
                {
                    return gameManager.Gold >= nextLevel.cost;
                }
            }
        }
        else if (x == 'm')
        {
            if (MageTower != null)
            {
                TowerData towerData = MageTower.GetComponent<TowerData>();
                TowerLevel nextLevel = towerData.GetNextLevel();
                if (nextLevel != null)
                {
                    return gameManager.Gold >= nextLevel.cost;
                }
            }
        }
        return false;
    }

    void OnMouseUp()
    {
        if (Input.GetKey("a") || gameManager.TowerSelection == 'a')
        {
            if (CanPlaceTower('a'))
            {
                ArrowTower = (GameObject)Instantiate(ArrowTowerPrefab, transform.position, Quaternion.identity);
                gameManager.Gold -= ArrowTower.GetComponent<TowerData>().CurrentLevel.cost;
            }
            else if (CanUpgradeTower('a'))
            {
                ArrowTower.GetComponent<TowerData>().IncreaseLevel();
                gameManager.Gold -= ArrowTower.GetComponent<TowerData>().CurrentLevel.cost;
            }
        }
        else if (Input.GetKey("c") || gameManager.TowerSelection == 'c')
        {
            if (CanPlaceTower('c'))
            {
                CannonTower = (GameObject)Instantiate(CannonTowerPrefab, transform.position, Quaternion.identity);
                gameManager.Gold -= CannonTower.GetComponent<TowerData>().CurrentLevel.cost;
            }
            else if (CanUpgradeTower('c'))
            {
                CannonTower.GetComponent<TowerData>().IncreaseLevel();
                gameManager.Gold -= CannonTower.GetComponent<TowerData>().CurrentLevel.cost;
            }
        }
        else if (Input.GetKey("m") || gameManager.TowerSelection == 'm')
        {
            if (CanPlaceTower('m'))
            {
                MageTower = (GameObject)Instantiate(MageTowerPrefab, transform.position, Quaternion.identity);
                gameManager.Gold -= MageTower.GetComponent<TowerData>().CurrentLevel.cost;
            }
            else if (CanUpgradeTower('m'))
            {
                MageTower.GetComponent<TowerData>().IncreaseLevel();
                gameManager.Gold -= MageTower.GetComponent<TowerData>().CurrentLevel.cost;
            }
        }
    }
}
