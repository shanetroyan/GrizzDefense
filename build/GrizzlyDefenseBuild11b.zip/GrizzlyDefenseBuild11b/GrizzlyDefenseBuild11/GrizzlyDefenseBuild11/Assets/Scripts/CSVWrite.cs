﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

public class CSVWrite : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        string filePath = @"C:\Users\Shane\Desktop\Scoreboard.csv";
                     string delimiter = ",";
                   string[][] output = new string[][]{
                   new string[]{"Username", "Highscore", "Date"},
                  
              };
                     int length = output.GetLength(0);
                      StringBuilder sb = new StringBuilder();
                for (int index = 0; index < length; index++)
                              sb.AppendLine(string.Join(delimiter, output[index]));
        
             File.WriteAllText(filePath, sb.ToString());
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
