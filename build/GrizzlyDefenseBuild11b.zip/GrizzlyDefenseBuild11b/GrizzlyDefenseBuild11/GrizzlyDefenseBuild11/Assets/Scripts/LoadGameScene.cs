﻿using UnityEngine;
using UnityEngine.SceneManagement;
public class LoadGameScene : MonoBehaviour
    {
       public void ChangeGameScene(string scenename)
        {
            

            

                Application.LoadLevel(scenename);
            }
        }
    






