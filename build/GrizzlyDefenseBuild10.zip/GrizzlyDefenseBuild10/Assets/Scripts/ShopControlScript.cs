﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class ShopControlScript : MonoBehaviour {

	int moneyAmount;
	int isArrowTowerSold;
    int isCannonTowerSold;
    int isMageTowerSold;

	public Text ArrowTowerText;
    public Text CannonTowerText;
    public Text MageTowerText;
	//public Text ArrowTowPrice;
    //public Text CannonTowPrice;
    //public Text MageTowPrice;
    public Text CurrentGoldPrice;

    public Button BuyArrowTowerBtn;
    public Button BuyCannonTowerBtn;
    public Button BuyMageTowerBtn;

    private GameManagerBehaviour gameManager;

    

    // Use this for initialization
    void Start () {
        GameObject gm = GameObject.Find("GameManager");
        gameManager = gm.GetComponent<GameManagerBehaviour>();
    }
	
	// Update is called once per frame
	void Update () {

        CurrentGoldPrice.text = "Current Gold:"+ " "+ gameManager.Gold.ToString();
        isArrowTowerSold = PlayerPrefs.GetInt ("IsArrowTowerSold");

		if (gameManager.Gold>= 60)
			BuyArrowTowerBtn.interactable = true;
		else
			BuyArrowTowerBtn.interactable = false;	
	

        isCannonTowerSold = PlayerPrefs.GetInt("IsCannonTowerSold");

		if (gameManager.Gold>= 100)
			BuyCannonTowerBtn.interactable = true;
		else
			BuyCannonTowerBtn.interactable = false;

        isMageTowerSold = PlayerPrefs.GetInt("IsMageTowerSold");

        if (gameManager.Gold >= 100)
            BuyMageTowerBtn.interactable = true;
        else
            BuyMageTowerBtn.interactable = false;
    }




public void buyArrowTower()
	{

        gameManager.Gold -= 60;
        PlayerPrefs.SetInt ("IsArrowTowerSold", 1);
		
        gameManager.ArrowTowerQty += 1;
		
	}
    public void buyMageTower()
    {

        gameManager.Gold -= 100;
        PlayerPrefs.SetInt("IsArrowTowerSold", 1);
        
        gameManager.MageTowerQty += 1;
        
    }

    public void buyCannonTower()
    {

        gameManager.Gold -= 100;
        PlayerPrefs.SetInt("IsCannonTowerSold", 1);
        
        gameManager.CannonTowerQty += 1;
        
    }





}
