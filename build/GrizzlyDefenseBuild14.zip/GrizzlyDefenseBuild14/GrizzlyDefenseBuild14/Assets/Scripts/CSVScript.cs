﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System;

public class CSVScript : MonoBehaviour
{

    private List<string[]> rowData = new List<string[]>();
    private GameManagerBehaviour gameManager;


    // Use this for initialization
    void Start()
    {

   
        
            GameObject gm = GameObject.Find("GameManager");
            gameManager = gm.GetComponent<GameManagerBehaviour>();
        

        Save();
    }

    void Save()
    {
        ;

        // Creating First row of titles manually..
        string[] rowDataValue = new string[2];
        rowDataValue[0] = "Username";
        rowDataValue[1] = "Score";
        
        rowData.Add(rowDataValue);

        // You can add up the values in as many cells as you want.
        for (int i = 0; i < 1; i++)
        {
             
            rowDataValue = new string[3];
            rowDataValue[0] = "";  // name
            rowDataValue[1] = "" + gameManager.Points.ToString();
            rowData.Add(rowDataValue) ;
        }

        string[][] output = new string[rowData.Count][];

        for (int i = 0; i < output.Length; i++)
        {
            output[i] = rowData[i];
        }

        int length = output.GetLength(0);
        string delimiter = ",";

        StringBuilder sb = new StringBuilder();

        for (int index = 0; index < length; index++)
            sb.AppendLine(string.Join(delimiter, output[index]));


        string filePath = getPath();

        StreamWriter outStream = System.IO.File.CreateText(filePath);
        outStream.WriteLine(sb);
        outStream.Close();
    }

    // Following method is used to retrive the relative path as device platform
    private string getPath()
    {
#if UNITY_EDITOR
        return @"C:\Users\Shane\Desktop\Scoreboard.csv";
#endif
    }
}

