﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AddNewTower : MonoBehaviour
{
    public GameObject ArrowTowerPrefab;
    private GameObject ArrowTower;
    private GameManagerBehaviour gameManager;


    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManagerBehaviour>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private bool CanPlaceTower()
    {
        int cost = ArrowTowerPrefab.GetComponent<TowerData>().levels[0].cost;
        return ArrowTower == null && gameManager.Gold >= cost;
    }

    void OnMouseUp()
    {
        if (CanPlaceTower())
        {
            ArrowTower = (GameObject)Instantiate(ArrowTowerPrefab, transform.position, Quaternion.identity);
            gameManager.Gold -= ArrowTower.GetComponent<TowerData>().CurrentLevel.cost;
        }
        else if (CanUpgradeTower())
        {
            ArrowTower.GetComponent<TowerData>().IncreaseLevel();
            gameManager.Gold -= ArrowTower.GetComponent<TowerData>().CurrentLevel.cost;
        }
    }

    private bool CanUpgradeTower()
    {
        if (ArrowTower != null)
        {
            TowerData towerData = ArrowTower.GetComponent<TowerData>();
            TowerLevel nextLevel = towerData.GetNextLevel();
            if (nextLevel != null)
            {
                return gameManager.Gold >= nextLevel.cost;
            }
        }
        return false;
    }
}
