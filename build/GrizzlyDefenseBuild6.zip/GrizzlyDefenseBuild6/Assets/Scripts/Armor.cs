﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "New Armor Type")]
public class Armor : ScriptableObject
{
    public DamageType damagetype;
    public float damageReduction;
}

