﻿using UnityEngine;
using UnityEngine.SceneManagement;
public class ReturntoMainMenu : MonoBehaviour
{
    public void ChangeGameScene(string scenename)
    {




        Application.LoadLevel(scenename);
    }
}

