﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class ShopControlScript : MonoBehaviour {

	int moneyAmount;
	public Text ArrowTowerText;
    public Text CannonTowerText;
    public Text MageTowerText;
	public Text ArrowTowPrice;
    public Text CannonTowPrice;
    public Text MageTowPrice;
    public Text CurrentGoldPrice;

    public Button BuyArrowTowerBtn;
    public Button BuyCannonTowerBtn;
    public Button BuyMageTowerBtn;

    private GameManagerBehaviour gameManager;

    

    // Use this for initialization
    void Start ()
    {
        GameObject gm = GameObject.Find("GameManager");
        gameManager = gm.GetComponent<GameManagerBehaviour>();
    }
	
	// Update is called once per frame
	void Update ()
    {
        CurrentGoldPrice.text = "Current Gold:"+ " "+ gameManager.Gold.ToString();
    }

    public void buyArrowTower()
	{
        gameManager.TowerSelection = 'a';
    }

    public void buyMageTower()
    {
        gameManager.TowerSelection = 'm';
    }

    public void buyCannonTower()
    {
        gameManager.TowerSelection = 'c';
    }
}
