﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenOptionsPanel : MonoBehaviour { 

    public GameObject OptionsScreen;

    public void OpenOptions()
    {
        if(OptionsScreen != null)
        {
            bool isActive = OptionsScreen.activeSelf;

            OptionsScreen.SetActive(!isActive);
        }
    }
  
 


}
