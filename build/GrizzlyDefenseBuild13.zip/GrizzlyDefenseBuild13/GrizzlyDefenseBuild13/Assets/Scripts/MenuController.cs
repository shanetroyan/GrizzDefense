﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuController : MonoBehaviour
{
    // Start is called before the first frame update

    public string MainMenuScene;
    public GameObject PauseScreen;
    public bool isPaused;
    public bool isFast;
    public bool isSlow;
    public bool isStoreOpen;
    public GameObject InGameStoreScreen;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.F))
        {
            if (isFast)
            {
                
                isFast = false;
                
                Time.timeScale = 1f;                
            }
            else
            {
                
                isFast = true;
                isPaused = false;
                PauseScreen.SetActive(false);
                InGameStoreScreen.SetActive(false);

                Time.timeScale = 3f;
                
            }
        }


        if(Input.GetKeyDown(KeyCode.S))
        {
            if (isStoreOpen)
                 
            {
               
                isStoreOpen = false;
                InGameStoreScreen.SetActive(false);
                PauseScreen.SetActive(false);
                Time.timeScale = 1f;
            }
        else
            {
                isStoreOpen = true;
                InGameStoreScreen.SetActive(true);
                PauseScreen.SetActive(false);
                Time.timeScale = .001f;
                isFast = false;
            }
        }




        if (Input.GetKeyDown(KeyCode.Escape)||(Input.GetKeyDown(KeyCode.P)))
        {
            if (isPaused)
            {
                  
                isPaused = false;
                PauseScreen.SetActive(false);
                Time.timeScale = 1f;
            }
            else
            {
                
                    isPaused = true;
                PauseScreen.SetActive(true);
                InGameStoreScreen.SetActive(false);
                Time.timeScale = 0.0001f;
                isFast = false;
            }

        }
    }
    public void resumeGame()
    {
        isPaused = false;
        isStoreOpen = false;
        PauseScreen.SetActive(false);
        InGameStoreScreen.SetActive(false);
        Time.timeScale = 1f;
    }

    public void ReturntoMainMenu()
    {
        SceneManager.LoadScene(MainMenuScene);
    }

}
