﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ArrowBehaviour : MonoBehaviour
{

    public float speed = 10;
    public float damage;
    
    public DamageType damagetype;
    public GameObject target;
    public Vector3 startPosition;
    public Vector3 targetPosition;

    private float distance;
    private float startTime;

    private GameManagerBehaviour gameManager;

    // Start is called before the first frame update
    void Start()
    {
        startTime = Time.time;
        distance = Vector2.Distance(startPosition, targetPosition);
        GameObject gm = GameObject.Find("GameManager");
        gameManager = gm.GetComponent<GameManagerBehaviour>();
    }

    // Update is called once per frame
    void Update()
    {
        // 1 
        float timeInterval = Time.time - startTime;
        gameObject.transform.position = Vector3.Lerp(startPosition, targetPosition, timeInterval * speed / distance);

        // 2 
        if (gameObject.transform.position.Equals(targetPosition))
        {
            if (target != null)
            {
                // 3
                Transform healthBarTransform = target.transform.Find("HealthBar");
                HealthBar healthBar =
                    healthBarTransform.gameObject.GetComponent<HealthBar>();
                if (healthBar.armor != null && healthBar.armor.damagetype == damagetype)
                {
                    damage -= damage * healthBar.armor.damageReduction;
                }
                healthBar.currentHealth -= Mathf.Max(damage, 0);
                // 4
                if (healthBar.currentHealth <= 0)
                {
                    string enemyName = target.name;

                    if (enemyName == "goblin(Clone)")
                    {
                        gameManager.Gold += 5;
                        gameManager.Points += 5;
                    }
                    else if (enemyName == "orc(Clone)")
                    {
                        gameManager.Gold += 10;
                        gameManager.Points += 10;
                    }
                    else if (enemyName == "wolfRider(Clone)")
                    {
                        gameManager.Gold += 10;
                        gameManager.Points += 10;
                    }
                    else if (enemyName == "ogre(Clone)")
                    {
                        gameManager.Gold += 50;
                        gameManager.Points += 50;
                    }

                    Destroy(target);
                }
            }
            Destroy(gameObject);
        }
    }
}
