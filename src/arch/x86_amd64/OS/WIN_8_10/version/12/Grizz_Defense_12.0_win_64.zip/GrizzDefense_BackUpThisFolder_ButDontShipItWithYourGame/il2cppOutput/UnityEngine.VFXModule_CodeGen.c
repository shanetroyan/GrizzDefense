﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void UnityEngine.Experimental.VFX.VFXEventAttribute::Release()
extern void VFXEventAttribute_Release_m5D6AD87AE348C7AF7EC545AE447341B845C7CC9E ();
// 0x00000002 System.Void UnityEngine.Experimental.VFX.VFXEventAttribute::Finalize()
extern void VFXEventAttribute_Finalize_mAB3C8D83EC862930F4F1D61FE3CCD1A739910D6E ();
// 0x00000003 System.Void UnityEngine.Experimental.VFX.VFXEventAttribute::Internal_Destroy(System.IntPtr)
extern void VFXEventAttribute_Internal_Destroy_mB0CAF455AAB70E08FA405D9AF763169389659C1C ();
// 0x00000004 System.Void UnityEngine.Experimental.VFX.VFXExpressionValues::.ctor()
extern void VFXExpressionValues__ctor_m027151E5BD0EDF382A29A73EF93705A5D0A40082 ();
// 0x00000005 UnityEngine.Experimental.VFX.VFXExpressionValues UnityEngine.Experimental.VFX.VFXExpressionValues::CreateExpressionValuesWrapper(System.IntPtr)
extern void VFXExpressionValues_CreateExpressionValuesWrapper_m4189CBC89E1C2B1F843133201D0E0B56A6845426 ();
// 0x00000006 System.Void UnityEngine.Experimental.VFX.VFXSpawnerCallbacks::.ctor()
extern void VFXSpawnerCallbacks__ctor_m0534B3E2B51CAE6F6ABBFDF5000775257A905172 ();
// 0x00000007 System.Void UnityEngine.Experimental.VFX.VFXSpawnerCallbacks::OnPlay(UnityEngine.Experimental.VFX.VFXSpawnerState,UnityEngine.Experimental.VFX.VFXExpressionValues,UnityEngine.Experimental.VFX.VisualEffect)
// 0x00000008 System.Void UnityEngine.Experimental.VFX.VFXSpawnerCallbacks::OnUpdate(UnityEngine.Experimental.VFX.VFXSpawnerState,UnityEngine.Experimental.VFX.VFXExpressionValues,UnityEngine.Experimental.VFX.VisualEffect)
// 0x00000009 System.Void UnityEngine.Experimental.VFX.VFXSpawnerCallbacks::OnStop(UnityEngine.Experimental.VFX.VFXSpawnerState,UnityEngine.Experimental.VFX.VFXExpressionValues,UnityEngine.Experimental.VFX.VisualEffect)
// 0x0000000A System.Void UnityEngine.Experimental.VFX.VFXSpawnerState::.ctor(System.IntPtr,System.Boolean)
extern void VFXSpawnerState__ctor_mFD378E315F4E31CCBFF59AE45CC16C205AD8296A ();
// 0x0000000B UnityEngine.Experimental.VFX.VFXSpawnerState UnityEngine.Experimental.VFX.VFXSpawnerState::CreateSpawnerStateWrapper()
extern void VFXSpawnerState_CreateSpawnerStateWrapper_m30974FFC2B48B9CC544FE6232707FAAE1E3508D3 ();
// 0x0000000C System.Void UnityEngine.Experimental.VFX.VFXSpawnerState::SetWrapValue(System.IntPtr)
extern void VFXSpawnerState_SetWrapValue_m29CEBB72B0F4E8CF1588B7F0FB5401698439A377 ();
// 0x0000000D System.Void UnityEngine.Experimental.VFX.VFXSpawnerState::Release()
extern void VFXSpawnerState_Release_m3ACF651636DFC2E2906852941ADE8FCAC5F1E087 ();
// 0x0000000E System.Void UnityEngine.Experimental.VFX.VFXSpawnerState::Finalize()
extern void VFXSpawnerState_Finalize_m2D89A26E4763AFFFCAD6259D7E69B167107635C9 ();
// 0x0000000F System.Void UnityEngine.Experimental.VFX.VFXSpawnerState::Dispose()
extern void VFXSpawnerState_Dispose_m8544BD06CE3576FB86ACD3945844B29BAE54CBD1 ();
// 0x00000010 System.Void UnityEngine.Experimental.VFX.VFXSpawnerState::Internal_Destroy(System.IntPtr)
extern void VFXSpawnerState_Internal_Destroy_m75C24AC41F75F4103F2CE75B7657CE982C5E3789 ();
static Il2CppMethodPointer s_methodPointers[16] = 
{
	VFXEventAttribute_Release_m5D6AD87AE348C7AF7EC545AE447341B845C7CC9E,
	VFXEventAttribute_Finalize_mAB3C8D83EC862930F4F1D61FE3CCD1A739910D6E,
	VFXEventAttribute_Internal_Destroy_mB0CAF455AAB70E08FA405D9AF763169389659C1C,
	VFXExpressionValues__ctor_m027151E5BD0EDF382A29A73EF93705A5D0A40082,
	VFXExpressionValues_CreateExpressionValuesWrapper_m4189CBC89E1C2B1F843133201D0E0B56A6845426,
	VFXSpawnerCallbacks__ctor_m0534B3E2B51CAE6F6ABBFDF5000775257A905172,
	NULL,
	NULL,
	NULL,
	VFXSpawnerState__ctor_mFD378E315F4E31CCBFF59AE45CC16C205AD8296A,
	VFXSpawnerState_CreateSpawnerStateWrapper_m30974FFC2B48B9CC544FE6232707FAAE1E3508D3,
	VFXSpawnerState_SetWrapValue_m29CEBB72B0F4E8CF1588B7F0FB5401698439A377,
	VFXSpawnerState_Release_m3ACF651636DFC2E2906852941ADE8FCAC5F1E087,
	VFXSpawnerState_Finalize_m2D89A26E4763AFFFCAD6259D7E69B167107635C9,
	VFXSpawnerState_Dispose_m8544BD06CE3576FB86ACD3945844B29BAE54CBD1,
	VFXSpawnerState_Internal_Destroy_m75C24AC41F75F4103F2CE75B7657CE982C5E3789,
};
static const int32_t s_InvokerIndices[16] = 
{
	23,
	23,
	25,
	23,
	18,
	23,
	175,
	175,
	175,
	139,
	4,
	7,
	23,
	23,
	23,
	25,
};
extern const Il2CppCodeGenModule g_UnityEngine_VFXModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_VFXModuleCodeGenModule = 
{
	"UnityEngine.VFXModule.dll",
	16,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
