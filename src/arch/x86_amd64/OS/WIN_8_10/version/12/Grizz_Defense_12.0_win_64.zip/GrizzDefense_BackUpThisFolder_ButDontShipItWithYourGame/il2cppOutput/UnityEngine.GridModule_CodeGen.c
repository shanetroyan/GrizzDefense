﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void UnityEngine.GridLayout::DoNothing()
extern void GridLayout_DoNothing_m0ED53398C0D9944BB9666DD66AD9940DE931A54C ();
static Il2CppMethodPointer s_methodPointers[1] = 
{
	GridLayout_DoNothing_m0ED53398C0D9944BB9666DD66AD9940DE931A54C,
};
static const int32_t s_InvokerIndices[1] = 
{
	23,
};
extern const Il2CppCodeGenModule g_UnityEngine_GridModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_GridModuleCodeGenModule = 
{
	"UnityEngine.GridModule.dll",
	1,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
