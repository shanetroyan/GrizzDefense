﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Object UnityEngine.JsonUtility::FromJsonInternal(System.String,System.Object,System.Type)
extern void JsonUtility_FromJsonInternal_mE4EF48FC77B4B25155BB039E477D4181E9E55E69 ();
// 0x00000002 System.Void UnityEngine.JsonUtility::FromJsonOverwrite(System.String,System.Object)
extern void JsonUtility_FromJsonOverwrite_mBBBDCD9B8641C1CFC6DBF22778AD399D5325D90A ();
static Il2CppMethodPointer s_methodPointers[2] = 
{
	JsonUtility_FromJsonInternal_mE4EF48FC77B4B25155BB039E477D4181E9E55E69,
	JsonUtility_FromJsonOverwrite_mBBBDCD9B8641C1CFC6DBF22778AD399D5325D90A,
};
static const int32_t s_InvokerIndices[2] = 
{
	2,
	141,
};
extern const Il2CppCodeGenModule g_UnityEngine_JSONSerializeModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_JSONSerializeModuleCodeGenModule = 
{
	"UnityEngine.JSONSerializeModule.dll",
	2,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
